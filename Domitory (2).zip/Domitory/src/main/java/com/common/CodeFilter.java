package com.common;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import java.io.IOException;

/**
 *  *表示对所有页面进行过滤
 */
@WebFilter(value="/*")
public class CodeFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("init");
    }

    /**
     *
     * @param servletRequest 请求的父接口
     * @param servletResponse 响应的父接口
     * @param filterChain 过滤链条，传递请求和响应
     * @throws IOException
     * @throws ServletException
     */
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
     //设置请求编码
        servletRequest.setCharacterEncoding("utf8");
                servletResponse.setContentType("text/html;charset=utf8");
        System.out.println("doFilter");
                filterChain.doFilter(servletRequest,servletResponse);

    }

    @Override
    public void destroy() {

    }
}
