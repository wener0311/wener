package com.common;
/**
 * 1.连接方法
 * 2.插入，删除及修改方法
 * 3.查询方法
 */


import java.lang.reflect.Field;
import java.sql.*;
import java.util.ArrayList;


public class DataConnection {
    //属性
    public static Connection con;
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dormitory?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT","root","root");
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    public static Connection getConn() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/dormitory?useUnicode=true&characterEncoding=utf-8&useSSL=false&serverTimezone=GMT","root","root");
            return con;
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
    /**
     *
     * @param sql 参数为insert,delete,update语句
     * @param data 可选参数
     * @return
     */
    public static int dataupdate(String sql,Object...data) {
        try {
            //当没有连接或连接关闭时
            if(con==null||con.isClosed()) {
                //得到连接
                con=getConn();
            }
            //根据连接得到语句对象
            PreparedStatement st=con.prepareStatement(sql);
            //给占位符赋值
            for (int i = 0; i < data.length; i++) {
                st.setObject(i+1, data[i]);//第一个参数为位置 第二个参数为数据
            }
            //执行sql
            return st.executeUpdate();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return -1;
    }
    /**
     *
     * @param sql 查询语句
     * @param data 可选数组 相当于对象数组
     * @return 返回值为结果集接口
     */
    public static ResultSet dataSelect(String sql,Object...data) {
        try {
            //当没有连接或连接关闭时
            if(con==null||con.isClosed()) {
                //得到连接
                con=getConn();
            }
            //根据连接得到语句对象
            PreparedStatement st=con.prepareStatement(sql);
            //给占位符赋值
            for (int i = 0; i < data.length; i++) {
                st.setObject(i+1, data[i]);//第一个参数为位置 第二个参数为数据
            }
            //执行sql
            return st.executeQuery();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
    /**
     *
     * @param <T>
     * @param rs 结果集接口
     * @param c  运行时class对象
     * @return 将结果集的数据导入到集合list中
     */
    public static<T>ArrayList<T>dataBean(ResultSet rs,Class<T>c){
        ArrayList<T>data=new ArrayList<T>();
        try {
            //结果集刚开始位于表头，第一条记录之前 rs.next()指向下一条记录
            while(rs.next()) {
                //先将结果集数据装入对象，再将对象装入到集合中
                T obj=c.newInstance();
                //得到所有属性
                Field f[]=c.getDeclaredFields();
                for (int i = 0; i < f.length; i++) {
                    //设置访问权限;
                    f[i].setAccessible(true);

                    Object vObject=rs.getObject(i+1);
                    if (vObject==null) {

                        f[i].set(obj,0);
                    } else {
                        //赋值 第一个参数为属性依赖的对象 第二个参数为数据
                        f[i].set(obj,rs.getObject(i+1));

                    }
                }
                data.add(obj);
            }
            return data;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InstantiationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }
}
