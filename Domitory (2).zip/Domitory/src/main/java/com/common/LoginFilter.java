package com.common;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebFilter(value="/admin/*")
public class LoginFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest req=(HttpServletRequest)servletRequest;
        //得到session接口
        HttpSession session=req.getSession();
        //取数据
        Object data=session.getAttribute("ad");
        if(data!=null){
            //放行资源
            filterChain.doFilter(servletRequest,servletResponse);
        }else{
         //跳转到登陆页面
            HttpServletResponse response=(HttpServletResponse)servletResponse;
           //req.getContextPath()表示项目路径
            response.sendRedirect(req.getContextPath()+"/Adminlogin.html");
        }
    }

    @Override
    public void destroy() {

    }
}
