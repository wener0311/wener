package com.service;

import com.bean.Dormitory_admin;
import com.bean.System_admin;
import com.common.DataConnection;

import java.sql.ResultSet;
import java.util.List;

public class Admins {
    public System_admin selectBynameAndPwd(String username, String password,String name) {
        String sql = "select * from system_admin where username=? and password=? and name=?";
        return DataConnection.dataBean(DataConnection.dataSelect(sql, username, password,name), System_admin.class).get(0);

    }
}