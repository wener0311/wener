package com.service;

import com.bean.Dormitory_admin;
import com.common.DataConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class DormitoryAdmins {
    public int AdminsInsert( String username , String password,String name,String gender,String telephone) {
            String sql = "insert into dormitory_admin values(default,?,?,?,?,?)";
            return DataConnection.dataupdate(sql, username, password,name,gender,telephone);
        }
    public int AdminDelete(String id){
        String sql="delete from dormitory_admin where id=?";
        return DataConnection.dataupdate(sql,Integer.parseInt(id));
    }
    public List<Dormitory_admin> adminALl() {
        String sql = "select*from dormitory_admin";
        ResultSet rs = DataConnection.dataSelect(sql);
        //2种方式处理数据：一是将结果集导入list接口；二是使用反射调用
        return  DataConnection.dataBean(rs,Dormitory_admin.class);
    }
    public List<Dormitory_admin> adminOne(int id) {
        String sql = "select*from dormitory_admin where id=?";
        ResultSet rs = DataConnection.dataSelect(sql,id);
        //2种方式处理数据：一是将结果集导入list接口；二是使用反射调用
        return  DataConnection.dataBean(rs,Dormitory_admin.class);
    }
    public int update(Dormitory_admin s){
        String sql="update dormitory_admin set username=?,password=?,name=?,gender=? ,telephone=? where id=?";
        return DataConnection.dataupdate(sql,s.getUsername(),s.getPassword(),s.getName(),s.getGender(),s.getTelephone(),s.getId());

    }
}
