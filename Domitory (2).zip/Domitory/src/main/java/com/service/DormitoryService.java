package com.service;



import com.bean.Dormitory;
import com.common.DataConnection;

import javax.servlet.http.Part;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/**
 * 宿舍相关的插入、删除、修改、查询方法
 */
public class DormitoryService {

    public int dormitoryInsert(Dormitory a) {
        String sql = "INSERT INTO dormitory values (default,?, ?, ?, ?, ?)";
        Connection con = DataConnection.con;
        try {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, a.getBuildingId());
            pst.setString(2, a.getName());
            pst.setInt(3, a.getType());
            pst.setInt(4, a.getAvailable());
            pst.setString(5, a.getTelephone());
            return pst.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 查询所有宿舍信息
     *
     * @return 所有宿舍的信息列表
     */
    public List<Dormitory> dormitoryAll() throws SQLException {
        String sql = "select*from dormitory";
        ResultSet rs = DataConnection.dataSelect(sql);
        List<Dormitory> data = new ArrayList<>();
        while (rs.next()) {
            //先装入对象，再装入集合中
            Dormitory e = new Dormitory();
            e.setId(rs.getInt(1));
            e.setBuildingId(rs.getInt(2));
            e.setName(rs.getString(3));
            e.setType(rs.getInt(4));
            e.setAvailable(rs.getInt(5));
            e.setTelephone(rs.getString(6));
            data.add(e);
        }
        return data;
    }


    public int dormitoryDelete(int id) {
        String sql = "DELETE FROM dormitory WHERE id = ?";
        return DataConnection.dataupdate(sql, id);
    }

    /**
     * 查询单个宿舍信息
     *
     * @param id 宿舍ID
     * @return 单个宿舍的信息列表
     */
    public Dormitory dormitoryOne(int id) throws SQLException {
        String sql = "SELECT * FROM dormitory WHERE id = ?";
        ResultSet rs = DataConnection.dataSelect(sql, id);
        while (rs.next()) {
            //先装入对象，再装入集合中
            Dormitory e = new Dormitory();
            e.setId(rs.getInt(1));
            e.setBuildingId(rs.getInt(2));
            e.setName(rs.getString(3));
            e.setType(rs.getInt(4));
            e.setAvailable(rs.getInt(5));
            e.setTelephone(rs.getString(6));
            return e;
        }
        return null;
    }



    public int dormitoryUpdate( Dormitory e) throws SQLException {
        String sql = "UPDATE dormitory set building_id = ?, name = ?, type = ?, available = ?, telephone = ? where id = ?";
        Connection conn = DataConnection.con;
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, e.getBuildingId());
        pst.setString(2, e.getName());
        pst.setInt(3, e.getType());
        pst.setInt(4, e.getAvailable());
        pst.setString(5, e.getTelephone());
        pst.setInt(6, e.getId());
        return pst.executeUpdate();
    }

}