package com.service;

import com.bean.Build;
import com.common.DataConnection;

import java.sql.ResultSet;
import java.util.List;

public class BuildS {
    public int BuildInsert(String name,String introduction,int adminId){
        String sql="insert into building values(default,?,?,?)";
        return DataConnection.dataupdate(sql,name,introduction,adminId);
    }

    public List<Build>  buildAll(){
        String sql="SELECT * from building";
        ResultSet rs=DataConnection.dataSelect(sql);
        //2种方式处理数据：一是将结果集导入List接口  二是使用反射调用
        return DataConnection.dataBean(rs, Build.class);
    }
    public int buildDelete(String id){
        String sql="delete from building where id=?";
        return DataConnection.dataupdate(sql,Integer.parseInt(id));
    }
    public List<Build>  buildOne(int id){
        String sql="select * from building where id=?";
        ResultSet rs=DataConnection.dataSelect(sql,id);
        //2种方式处理数据：一是将结果集导入List接口  二是使用反射调用
        return DataConnection.dataBean(rs, Build.class);
    }
    public int buildUpdate(Build b){
        String sql="update building set name=?,introduction=?,admin_id=? where id=?";
        return DataConnection.dataupdate(sql,b.getName(),b.getIntroduction(),b.getAdminId(),b.getId());
    }

}

