package com.service;

import com.bean.Dormitory;
import com.bean.Student;
import com.common.DataConnection;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.common.DataConnection.con;

/**
 * 插入，删除，修改，查询方法
 */
public class StudentService {

    //        public int studentInsert (Integer id, String number, String name, String gender, Integer dormitory_id, String state, String create_date){
//        String sql = "insert into student values(?,?,?,?,?,?,?)";
//        return DataConnection.dataUpdate(sql,id, number, name, gender, dormitory_id, state, create_date);
//    }
    public int studentInsert(Student s) {
        String sql = "insert into student values(default,?,?,?,?,?,?)";
        //得到接口
        Connection con = DataConnection.con;
        try {
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, s.getNumber());
            pst.setString(2, s.getName());
            pst.setString(3, s.getGender());
            pst.setInt(4,s.getDormitoryId());
            pst.setString(5, s.getState());
            pst.setString(6, s.getCreateDate());
            return pst.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public List<Student> all() throws SQLException {
        String sql = "select * from student";
        ResultSet rs = DataConnection.dataSelect(sql);
        List<Student> data = new ArrayList<>();
        while (rs.next()) {
        Student s = new Student();
        s.setId(rs.getInt(1));
        s.setNumber(rs.getString(2));
        s.setName(rs.getString(3));
        s.setGender(rs.getString(4));
        s.setDormitoryId(rs.getInt(5));
        s.setState(rs.getString(6));
        s.setCreateDate(rs.getString(7));
        data.add(s);
    }
        return data;
    }
    public int studentDelete(int id) {
        String sql = "delete from student where id=?";
        return DataConnection.dataupdate(sql, id);
    }

    public Student one( int id) throws SQLException, IOException {
        String sql = "select * from student where id=?";
        ResultSet rs = DataConnection.dataSelect(sql, id);
       while(rs.next()) {
            //先装入对象，再装入集合中
            Student s = new Student();
            s.setId(rs.getInt(1));
            s.setNumber(rs.getString(2));
            s.setName(rs.getString(3));
            s.setGender(rs.getString(4));
            s.setDormitoryId(rs.getInt(5));
            s.setState(rs.getString(6));
            s.setCreateDate(rs.getString(7));
            return s;
        }
        return null;
    }
    public  int studentUpdate(Student s) throws SQLException, IOException {
        String  sql="update student set number=?,name=?,gender=?,dormitory_id=?,state=?,create_date=? where id=?";
        PreparedStatement pst=con.prepareStatement(sql);
        pst.setString(1, s.getNumber());
        pst.setString(2, s.getName());
        pst.setString(3, s.getGender());
        pst.setInt(4, s.getDormitoryId());
        pst.setString(5, s.getState());
        pst.setString(6, s.getCreateDate());
        pst.setInt(7, s.getId());
        return pst.executeUpdate();

    }
}


