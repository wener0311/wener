package com.service;

import com.bean.Build;
import com.bean.Dormitory;
import com.bean.Student;
import com.common.DataConnection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class lists {
    public List<Dormitory> all() throws SQLException {
        String sql = "select a.name,type,telephone,b.name,introduction,number,c.name,gender from dormitory a,building b,student c where a.building_id=b.id and a.id=c.dormitory_id";
        ResultSet rs = DataConnection.dataSelect(sql);
        List<Dormitory> data = new ArrayList<>();
        while (rs.next()) {
            //先装入对象，再装入集合中
            Dormitory e = new Dormitory();
            e.setName(rs.getString(1));
            e.setType(rs.getInt(2));
            e.setTelephone(rs.getString(3));
            Build b = new Build();
            b.setName(rs.getString(4));
            b.setIntroduction(rs.getString(5));
            Student c = new Student();
            e.setB(b);
            c.setNumber(rs.getString(6));
            c.setName(rs.getString(7));
            c.setGender(rs.getString(8));
            e.setS(c);
            data.add(e);
        }
        return data;
    }
    public int getPages() throws SQLException {
        String sql="select count(*) from dormitory a,building b,student c where a.building_id=b.id and a.id=c.dormitory_id";
        ResultSet rs=DataConnection.dataSelect(sql);
        if(rs.next()){
            int len=rs.getInt(1);
            return(int)Math.ceil(len/10.0);
        }
        return 0;
    }
    public List<Dormitory>all(int cur) throws SQLException {
        String sql="select a.name,type,telephone,b.name,introduction,number,c.name,gender from dormitory a,building b,student c where a.building_id=b.id and a.id=c.dormitory_id limit ?,10";
        ResultSet rs=DataConnection.dataSelect(sql,(cur-1)*10);
        List<Dormitory>data=new ArrayList<>();
        while (rs.next()) {
            //先装入对象，再装入集合中
            Dormitory e = new Dormitory();
            e.setName(rs.getString(1));
            e.setType(rs.getInt(2));
            e.setTelephone(rs.getString(3));
            Build b = new Build();
            b.setName(rs.getString(4));
            b.setIntroduction(rs.getString(5));
            Student c = new Student();
            e.setB(b);
            c.setNumber(rs.getString(6));
            c.setName(rs.getString(7));
            c.setGender(rs.getString(8));
            e.setS(c);
            data.add(e);
        }
        return data;
    }
    }

