package com.control.Student;

import com.bean.Student;
import com.service.DormitoryService;
import com.service.StudentService;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(value = "/StudentUpdate")
@MultipartConfig
public class StudentUpdate  extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置请求编码
        req.setCharacterEncoding("utf8");
        //获取数据
        String number=req.getParameter("number");
        String name=req.getParameter("name");
        String  gender=req.getParameter("gender");
        String dormitory_id=req.getParameter("dormitory_id");
        String state=req.getParameter("state");
        String create_date=req.getParameter("create_date");
        Student s=new Student();
        s.setNumber(number);
        s.setName(name);
        s.setGender(gender);
        s.setDormitoryId(Integer.parseInt(dormitory_id));
        s.setState(state);
        s.setCreateDate(create_date);
        //编号s
        String id=req.getParameter("id");
        s.setId(Integer.parseInt(id));
        try {
            resp.getWriter().print(new StudentService().studentUpdate(s));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
