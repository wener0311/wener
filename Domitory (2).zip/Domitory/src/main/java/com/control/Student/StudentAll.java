package com.control.Student;


import com.bean.Student;
import com.google.gson.Gson;
import com.service.StudentService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(value = "/StudentAll")
public class StudentAll extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置响应编码
        resp.setContentType("text/html;charset=utf8");
        String path=req.getServletContext().getRealPath("upload");
        File f=new File(path);
        if (!f.exists())
            f.mkdir();
        try {
            resp.getWriter().print(new Gson().toJson(new StudentService().all()));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}

