package com.control.Student;


import com.bean.Student;
import com.service.StudentService;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(value = "/StudentInsert")
@MultipartConfig
public class StudentInsert extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //解决请求的乱码 ctrl+y删除所在行
        req.setCharacterEncoding("utf8");
        //获取数据
//        Integer id= Integer.parseInt(req.getParameter("id"));
        String number=req.getParameter("number");
        String name=req.getParameter("name");
        String gender=req.getParameter("gender");
        //外键
       String dormitory_id=req.getParameter("dormitory_id");
        String state=req.getParameter("state");
        String create_date=req.getParameter("create_date");


//        //调用服务层的方法将结果写入页面中
//        PrintWriter out=resp.getWriter();
//        //调用服务层方法
//        int r=new StudentService().studentInsert(id,number, name, gender, dormitory_id, state, create_date);
//        out.print(r);//参数值为插入方法的返回值
        //将数据装入对象，调用服务层方法，将执行的结果写入页面中
        Student s=new Student();
        s.setNumber(number);
        s.setName(name);
        s.setGender(gender);
        s.setDormitoryId(Integer.parseInt(dormitory_id));
        s.setState(state);
        s.setCreateDate(create_date);
        resp.getWriter().print(new StudentService().studentInsert(s));
    }


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
}