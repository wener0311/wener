package com.control.Student;

import com.service.StudentService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value = "/StudentDelete")
public class StudentDelete extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //取数据
        int id=Integer.parseInt(req.getParameter("id"));
        //调用服务层的删除方法将结果写入页面中
        resp.getWriter().print(new StudentService().studentDelete(id));
    }
}