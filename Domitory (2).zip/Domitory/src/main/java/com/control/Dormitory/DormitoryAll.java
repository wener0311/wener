package com.control.Dormitory;


import com.bean.Dormitory;
import com.google.gson.Gson;
import com.service.DormitoryService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet(value = "/DormitoryAll")
public class DormitoryAll extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 设置响应编码
        resp.setContentType("application/json;charset=utf-8");

        // 调用服务层的查询方法
        List<Dormitory> data = null;
        try {
            data = new DormitoryService().dormitoryAll();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        // 转换成 JSON 串
        Gson gson = new Gson();
        String json = gson.toJson(data);

        // 将结果写入页面中
        resp.getWriter().print(json);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}