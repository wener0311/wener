package com.control.Dormitory;

import com.bean.Build;
import com.bean.Dormitory;
import com.google.gson.Gson;
import com.service.BuildS;
import com.service.DormitoryService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@WebServlet(value = "/DormitoryOne")
public class DormitoryOne extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=utf8");
        //获取数据
        DormitoryService es=new DormitoryService();

        try {
            Dormitory e=es.dormitoryOne(Integer.parseInt(req.getParameter("id")));
            List<Build> list=new BuildS().buildAll();
            Map<String,Object> data=new HashMap<>();
            data.put("one",e);
            data.put("building_id",list);
            //将map转json串写入页面
            resp.getWriter().print((new Gson().toJson(data)));
        } catch (
                SQLException ex) {
            throw new RuntimeException(ex);
        }
    }
}
