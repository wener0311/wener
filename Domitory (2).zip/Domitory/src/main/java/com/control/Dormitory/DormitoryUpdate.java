package com.control.Dormitory;



import com.bean.Dormitory;
import com.service.DormitoryService;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(value = "/DormitoryUpdate")
@MultipartConfig
public class DormitoryUpdate extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String building_id=req.getParameter("building_id");
        String name = req.getParameter("name");
        String type = req.getParameter("type");
        String available = req.getParameter("available");
        String telephone = req.getParameter("telephone");

        //将数据装入对象，调用服务层方法，将执行的结果写入页面中
        Dormitory a=new Dormitory();
        a.setBuildingId(Integer.parseInt(building_id));
        a.setName(name);
        a.setType(Integer.parseInt(type));
        a.setAvailable(Integer.parseInt(available));
        a.setTelephone(telephone);
        String id=req.getParameter("id");
        a.setId(Integer.parseInt(id));

        try {
            resp.getWriter().print(new DormitoryService().dormitoryUpdate(a));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}