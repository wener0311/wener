package com.control.Admin;

import com.bean.System_admin;
import com.google.gson.Gson;
import com.service.Admins;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet(value="/AdminOne")
public class AdminOne extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf8");
        String name=req.getParameter("aname");
        String pwd=req.getParameter("apwd");
        String name1=req.getParameter("role");


        //调用服务层的方法得到管理员数据
        System_admin a=new Admins().selectBynameAndPwd(name,pwd,name1);
        if (a!=null){
            //将管理员数据存入session中
            HttpSession session=req.getSession();
            //保存后，可在其它servlet页面获取session
            session.setAttribute("ad",a);
            Map<String,Object> data=new HashMap<>();
            data.put("r",1);
            data.put("obj",a);
            //将map转json串写入页面中
            resp.getWriter().print(new Gson().toJson(data));
        }
    }
}
