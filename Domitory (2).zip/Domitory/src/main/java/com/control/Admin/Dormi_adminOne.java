package com.control.Admin;

import com.bean.Dormitory_admin;
import com.google.gson.Gson;
import com.service.DormitoryAdmins;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(value="/Dormi_adminOne")
public class Dormi_adminOne extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("test/html;charset=utf-8");
        //得到参数id
        String id = req.getParameter("id");
        //调用服务层查询一条方法得到对象
        List<Dormitory_admin> data = new DormitoryAdmins().adminOne(Integer.parseInt(id));
        //将得到的转JSON串写入到页面中
        resp.getWriter().print(new Gson().toJson(data));
    }
}
