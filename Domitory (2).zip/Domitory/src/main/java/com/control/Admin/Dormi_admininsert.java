package com.control.Admin;

import com.service.DormitoryAdmins;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(value="/Dormitory_admininsert")
public class Dormi_admininsert extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf8");
        //得到部门名称及位置
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        String name=req.getParameter("name");
        String gender=req.getParameter("gender");
        String telephone=req.getParameter("telephone");

        //调用服务层的方法将结果写入页面中
        PrintWriter out=resp.getWriter();
        int r=new DormitoryAdmins().AdminsInsert(username,password,name,gender,telephone);
        out.print(r);//参数为插入方法的返回值


    }
}
