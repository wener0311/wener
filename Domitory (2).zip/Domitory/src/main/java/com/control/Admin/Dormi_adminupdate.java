package com.control.Admin;

import com.bean.Dormitory_admin;
import com.service.DormitoryAdmins;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value="/Dormi_adminupdate")
public class Dormi_adminupdate extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置请求编码，请求数据不乱码
        req.setCharacterEncoding("utf8");
        //得到前端的数据，类型为字符串String
        String username=req.getParameter("username");
        String password=req.getParameter("password");
        String name=req.getParameter("name");
        String gender=req.getParameter("gender");
        String telephone=req.getParameter("telephone");
        String id=req.getParameter("id");

        //将数据装入对象中
        //将数据装入对象中
       Dormitory_admin s=new Dormitory_admin();
        s.setUsername(username);
        s.setPassword(password);
        s.setName(name);
        s.setGender(gender);
        s.setTelephone(telephone);
        s.setId(Integer.parseInt(id));
        //将执行的结果写入页面中
        resp.getWriter().print(new DormitoryAdmins().update(s));

    }
}
