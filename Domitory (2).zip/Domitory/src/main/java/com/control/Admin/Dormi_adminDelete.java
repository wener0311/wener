package com.control.Admin;

import com.service.Admins;
import com.service.DormitoryAdmins;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(value="/Dormi_adminDelete")
public class Dormi_adminDelete extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //取数据
        String id = req.getParameter("id");
        //调用服务层是的删除方法，将结果写入页面中
        resp.getWriter().print(new DormitoryAdmins().AdminDelete(id));
    }
}