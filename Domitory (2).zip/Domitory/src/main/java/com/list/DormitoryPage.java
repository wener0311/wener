package com.list;

import com.bean.Dormitory;
import com.google.gson.Gson;
import com.service.lists;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet(value="/DormitoryPage")
public class DormitoryPage extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=utf8");
        String cur=req.getParameter("cur");
        int cur2=0;
        if(cur==null||cur.equals("")){
            cur2=1;
        }else{
            cur2=Integer.parseInt(cur);
        }
        lists ls=new lists();

        int pages= 0;
        try {
            pages = ls.getPages();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        try {
            List<Dormitory>fenye=ls.all(cur2);
            Map<String,Object> data=new HashMap<>();
            data.put("cur",cur2);
            data.put("pages",pages);
            data.put("fenye",fenye);
            resp.getWriter().print(new Gson().toJson(data));
        } catch (SQLException e) {
            throw new RuntimeException(e);

        }


    }
}
