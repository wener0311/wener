//声明地址
let url="http://localhost:8080/";
// 第一个参数为字符串，第二个参数为键名
function getValue(str,key){
	// 得到?之后的字符串  str ?id=1&cid=2
	let str2=str.substring(1);//id=1&cid=2
	//按&进行拆分
	let data=str2.split("&");
	for (var i = 0; i < data.length; i++) {
		//再拆分
		let data2=data[i].split("=");
		if(data2[0]==key){
			return data2[1];
		}
	}
	return null;
}
//声明对象
let obj={
	getValue2:function(str,key){
		// 得到?之后的字符串  str ?id=1&cid=2
		let str2=str.substring(1);//id=1&cid=2
		//按&进行拆分
		let data=str2.split("&");
		for (var i = 0; i < data.length; i++) {
			//再拆分
			let data2=data[i].split("=");
			if(data2[0]==key){
				return data2[1];
			}
		}
		return null;
	}
}